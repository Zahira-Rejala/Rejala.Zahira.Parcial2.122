
package service;

import java.util.List;
import model.Hechizo;

public interface ServiceHechizos {
    static void listarEmpleados(List<? extends Hechizo> lista){
        lista.forEach(System.out::println);
    }
}
