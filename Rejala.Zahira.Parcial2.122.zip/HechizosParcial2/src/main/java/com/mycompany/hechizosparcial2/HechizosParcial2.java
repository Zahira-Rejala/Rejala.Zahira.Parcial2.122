package com.mycompany.hechizosparcial2;

import java.io.IOException;
import model.LibroDeHechizos;
import model.Hechizo;
import model.TipoHechizo;
import config.RutasArchivo;

public class HechizosParcial2 {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        try {
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();

            libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick",
                    TipoHechizo.DEFENSA));
            libro.agregar(new Hechizo(2, "Alohomora", "Desconocido",
                    TipoHechizo.UTILIDAD));
            libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape",
                    TipoHechizo.OSCURO));
            libro.agregar(new Hechizo(4, "Lumos", "Desconocido",
                    TipoHechizo.ENCANTAMIENTO));
            libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape",
                    TipoHechizo.CURACION));

            // Mostrar todos los hechizos 
            System.out.println("Hechizos:");
            libro.paraCadaElemento(p -> System.out.println(p.getNombre()));

            // Filtrar por tipo DEFENSA 
            System.out.println("\nHechizos de tipo DEFENSA:");
            libro.filtrar(h -> h.getTipo() == TipoHechizo.DEFENSA)
                    .forEach(h -> System.out.println(h.getNombre()));

            // Filtrar por nombre que contenga "lumos" 
            System.out.println("\nHechizos que contienen 'lumos':");
            libro.filtrar(h -> h.getNombre().toLowerCase().contains("lumus"))
                    .forEach(h -> System.out.println(h.getNombre()));

            // Ordenar hechizos por ID (orden natural) 
            System.out.println("\nHechizos ordenados por ID:");
            libro.iterator((h1, h2) -> Integer.compare(h1.getId(), h2.getId()));
            libro.paraCadaElemento(h -> System.out.println(h.getNombre()));

            // Ordenar hechizos por nombre 
            System.out.println("\nHechizos ordenados por nombre:");
            libro.iterator((h1, h2) -> h1.getNombre().compareToIgnoreCase(h2.getNombre()));

            // Guardar en archivo binario 
            libro.guardarEnArchivo("src/data/hechizos.dat");

            // Cargar desde archivo binario 
            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
            libroCargado.cargarDesdeArchivo("src/data/hechizos.dat");

            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(h -> System.out.println(h.getNombre()));

            // Guardar en archivo CSV 
            libro.guardarEnCSV(("src/data/hechizos.csv");

            // Cargar desde archivo CSV 
            libroCargado.cargarDesdeCSV("src/data/hechizos.csv", (linea -> {
                String[] datos = linea.split(",");
                int id = Integer.parseInt(datos[0]);
                String nombre = datos[1];
                String creador = datos[2];
                TipoHechizo tipo = TipoHechizo.valueOf(datos[3])
                ));
        System.out.println("\nHechizos cargados desde archivo CSV:");
                // libroCargado.paraCadaElemento(/* Lambda */);
            } catch (IOException | ClassNotFoundException e) { 
       System.err.println("Error: " + e.getMessage());
}
        }

    }}
