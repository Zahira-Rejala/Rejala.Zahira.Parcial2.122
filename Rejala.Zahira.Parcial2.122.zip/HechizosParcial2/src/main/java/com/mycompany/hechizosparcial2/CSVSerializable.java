
package com.mycompany.hechizosparcial2;


public interface CSVSerializable{
    public String toCSV();
}
