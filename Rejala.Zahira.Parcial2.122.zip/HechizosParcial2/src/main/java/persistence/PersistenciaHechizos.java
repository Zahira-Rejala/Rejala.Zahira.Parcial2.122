
package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import model.Hechizo;

public interface PersistenciaHechizos {
    
    static void serializarProductos(List<? extends Hechizo> lista, String path){
        try(ObjectOutputStream salida =
                new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }

        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    static List<Hechizo> deserealizarProductos(String path){
        List<Hechizo> toReturn = null;
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){
            toReturn = (List<Hechizo>)entrada.readObject();
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}
