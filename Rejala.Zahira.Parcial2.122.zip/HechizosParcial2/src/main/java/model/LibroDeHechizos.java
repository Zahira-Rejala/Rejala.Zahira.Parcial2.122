
package model;

import com.mycompany.hechizosparcial2.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class LibroDeHechizos<T extends CSVSerializable & Serializable> implements Serializable {
    private List<T> elementos;

    public LibroDeHechizos() {
        this.elementos = new ArrayList<>();
    }
    
    public void agregar(T elemento){
        elementos.add(elemento);
    }
    
    public T obtener(int indice){
        return elementos.get(indice);
    }
    
    public T eliminar(int indice){
        return elementos.remove(indice);
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T e : elementos) {
            accion.accept(e);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                resultado.add(elem);

            }
        }
        for (T elem : resultado) {
            System.out.println(elem);  
        }
        return resultado;
    }
    
    private List<T> copiarElementos() {
        return new ArrayList<>(elementos);
    }
    
    public Iterator<T> iterator(Comparator<? super T> c) {
        List<T> copia = copiarElementos();
        copia.sort(c);
        return copia.iterator();
    }
    
    public void guardarEnCSV(String ruta) throws IOException {
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
        for (T elem : elementos) {
            bw.write(elem.toCSV());
            bw.newLine();
        }
    }
}
    
    static List<Hechizo> cargarDesdeCSV(String path){
        List<Hechizo> toReturn = new ArrayList<>();
        try(BufferedReader lector = new BufferedReader(new FileReader(path))){
            String datos;
            lector.readLine();
            while((datos = lector.readLine()) != null){
                toReturn.add(Hechizo.fromCSV(datos));
            }
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
    
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }
    
     public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject(); 
        }
    }
}

