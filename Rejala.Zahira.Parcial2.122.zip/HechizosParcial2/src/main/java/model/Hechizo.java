
package model;

import com.mycompany.hechizosparcial2.CSVSerializable;
import java.io.Serializable;
import java.util.Objects;

public class Hechizo implements Serializable, Comparable<Hechizo>, CSVSerializable {
    private static final long serialVersionUID = 1L;
    private final int id;
    private final String nombre;
    private final String creador;
    private final TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return String.format(
        "Producto{id=%d, nombre=%s, creador=%.2f, tipo=%s}",
        id, nombre, creador, tipo
    );
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Hechizo p)){
            return false;
        } else {
            return id == p.id;
        }
    }

    @Override
    public int compareTo(Hechizo o) {
        return Integer.compare(id, o.id);
    }
    
    public String toCSV(){
        return id + "," + nombre + "," + creador + "," + tipo;
    }
    
    public static Hechizo fromCSV(String productoCSV){
        String[] datos = productoCSV.substring(0, productoCSV.length()).split(",");
        return new Hechizo(Integer.parseInt(datos[0]), datos[1], datos[2], TipoHechizo.valueOf(datos[3]));
    }
    
    public static String getHeaderCSV(){
        return "id,nombre,precio,tipo\n";
    }
    
}
